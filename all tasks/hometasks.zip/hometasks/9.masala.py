my_tuple = (2, 3, 4)
factor = 5
new_tuple = tuple(x * factor for x in my_tuple)
print(new_tuple)
