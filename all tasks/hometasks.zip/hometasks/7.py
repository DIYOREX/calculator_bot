# Masala: Elementni o'chirish
# Berilgan Listdan xavfni o'chiring. Agar qiymat Listda bo'lmasa, Listni o'zgartirmasdan qaytaring.

my_list = ["xavf", "foydali", "zararsiz"]
element_to_remove = "xavf"
if element_to_remove in my_list:
    my_list.remove(element_to_remove)
print(my_list)
