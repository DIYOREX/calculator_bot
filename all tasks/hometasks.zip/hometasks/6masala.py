# Masala: Katta Tuple yozish

# Ikki tupleni birlashtirib yangi Tupledagi yaratilish sonini qaytaring.

tuple1 = (1, 3, 4)
tuple2 = (5, 5, 6, 7)
new_tuple = tuple1+tuple2
lenth = len(new_tuple)
print('uzunligi: ', lenth)




