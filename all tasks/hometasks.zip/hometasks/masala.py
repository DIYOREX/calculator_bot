fruits = [("olma", 1500), ("banan", 2000), ("uzum", 3000)]
total_price = sum([price for name, price in fruits])
print(f"Mevalar: {fruits}, Jami narx: {total_price}")
