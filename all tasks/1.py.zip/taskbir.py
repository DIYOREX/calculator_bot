country = ["germany", 'france', 'russia', 'japan', 'canada']
print(len(country))

print(sorted(country))

sorted(country, reverse=True)
print(country)

country.reverse()
print(country)

country.sort()
print(country)

country.sort(reverse=True)
print(country)





