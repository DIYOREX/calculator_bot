info_humans = {}


def id_info():
    while input('Do you wanna add someone else? (y/n) ').startswith('y'):
        phone_number = input("Enter your phone number: ")

        name = input('Enter your full name: ')
        age = input('Enter your age: ')
        address = input('Enter your address: ')
        serial = input('Enter your passport serial (AB, AC, or AD): ')
        number = input('Enter your passport number: ')

        info_humans[phone_number] = {
            'name': name,
            'age': age,
            'address': address,
            'serial': serial,
            'number': number
        }

    print("Collected Information about people:", info_humans)


id_info()



                   
                    
                    
          



