def fruits_haqida(fruits):
    return sum(price for name, price in fruits)

fruits = [("olma", 1500), ("banan", 2000), ("uzum", 3000)]
total_price = fruits_haqida(fruits)
print(f"Mevalar: {fruits}, Jami narx: {total_price}")
