def elementni_ochir(my_list, element_to_remove):
    return [x for x in my_list if x != element_to_remove]

my_list = ["xavf", "foydali", "zararsiz"]
my_list = elementni_ochir(my_list, "xavf")
print(my_list)
