def elementlarni_kopaytir(my_tuple, factor):
    return tuple(x * factor for x in my_tuple)

my_tuple = (2, 3, 4)
new_tuple = elementlarni_kopaytir(my_tuple, 5)
print(new_tuple)
