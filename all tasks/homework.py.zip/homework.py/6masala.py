def birlashtir_va_sonini_qaytar(tuple1, tuple2):
    return (tuple1 + tuple2, len(tuple1 + tuple2))

tuple1 = (1, 2, 3)
tuple2 = (4, 5, 6)
new_tuple, element_count = birlashtir_va_sonini_qaytar(tuple1, tuple2)
print(f"Yangi Tuple: {new_tuple}, Elementlar soni: {element_count}")
