def elementni_ozgartir(my_tuple, index, new_value):
    return tuple(new_value if i == index else val for i, val in enumerate(my_tuple))

my_tuple = (10, 20, 30)
new_tuple = elementni_ozgartir(my_tuple, 1, 25)
print(new_tuple)
