def tuple_elementlarini_ol(my_list):
    return [element for tpl in my_list for element in tpl]

my_list = [(1, 2), (3, 4), (5, 6)]
new_list = tuple_elementlarini_ol(my_list)
print(new_list)
