
def kabisa_yili(yil):
    if (yil % 4 == 0 and yil % 100 != 0) or (yil % 400 == 0):
        return True
    return False

kiritilgan_malumot = int(input("ismingiz va tug'ilgan yilingizni probel bilan kiriting: "))

ism, yil = kiritilgan_malumot.split()


if kabisa_yili(yil):
    print(f"{ism} kabisa yilida tug'ilgan.")
else:
    print(f"{ism} kabisa yilida tug'ilmagan.")
