def raqam(num):
    if num < 2:
        return False
    for i in range(2, int(num**0.5) + 1):
        if num % i == 0:
            return False
    return True

def numbers_turlari(n):
    juft_sonlar = []
    toq_sonlar = []
    tub_sonlar = []

    for i in range(1, n+1):
        if i % 2 == 0:
            juft_sonlar.append(i)
        else:
            toq_sonlar.append(i)
        if raqam(i):
            tub_sonlar.append(i)

    print("Juft sonlar:", juft_sonlar)
    print("Toq sonlar:", toq_sonlar)
    print("Tub sonlar:", tub_sonlar)

N = int(input("son kiriting: "))
numbers_turlari(N)
