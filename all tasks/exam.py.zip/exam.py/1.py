
def big_age():
          name= input("enter your name: ")
          age = int(input("enter your age: "))
          name2 = input("enter your name: ")
          age2 = int(input("enter your age: "))
          if age > age2:
                    print(name)
          else:
                    print(name2) 
big_age()