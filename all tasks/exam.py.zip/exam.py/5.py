
words = []
def users_name():
          while True:
                    word = str(input("enter word:  "))
                    if word == 'exit':
                              print(f"Siz kiritgan so'zlar  {set(words)}")
                              break
                    else:
                              words.append(word)
                              continue
users_name()
          