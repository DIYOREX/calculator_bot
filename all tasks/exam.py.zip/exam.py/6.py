n = int(input("sonini kiriting: "))
db = {}

for i in range(1, n + 1):
    db[i] = i ** 2

print(db)
