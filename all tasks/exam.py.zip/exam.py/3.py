numbers_map = {
    1: "bir", 2: "ikki", 3: "uch", 4: "turt", 5: "besh",
    6: "olti", 7: "yetti", 8: "sakkiz", 9: "to'qqiz", 10: "un",
    11: "o'n bir", 12: "o'n ikki", 13: "o'n uch", 14: "o'n to'rt",
    15: "o'n besh", 16: "o'n olti", 17: "o'n yetti", 18: "o'n sakkiz",
    19: "o'n to'qqiz", 20: "yigirma", 30: "o'ttiz", 40: "qirq",
    50: "ellik", 60: "oltmish", 70: "yetmish", 80: "sakson", 90: "to'qson"
}

def number_to_words(number: int) -> str:
    
    
    if number == 0:
        return "nol"
    
    words = []
    
    hundreds = number // 100
    if hundreds > 0:
        words.append(f'{numbers_map[hundreds]} yuz')
    
    tens_ones = number % 100
    if tens_ones > 0:
        if tens_ones <= 20: 
            words.append(numbers_map[tens_ones])
        else:
            tens = (tens_ones // 10) * 10
            ones = tens_ones % 10
            words.append(numbers_map[tens])
            if ones > 0:
                words.append(numbers_map[ones])
    
    return ' '.join(words)


if __name__ == "__main__":
    try:
        number = int(input("raqam kiriting: "))
        print(number_to_words(number))
    except ValueError:
        print("xato son kiritingiz.")
