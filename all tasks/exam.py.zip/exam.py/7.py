users = [
    {'name': 'diyor', 'age': 20, 'gender': 'male'},
    {'name': 'madina', 'age': 17, 'gender': 'female'},
    {'name': 'numon', 'age': 25, 'gender': 'male'},
    {'name': 'muhayoo', 'age': 22, 'gender': 'female'},
    {'name': 'john', 'age': 19, 'gender': 'male'}
]

filtered_users = list(filter(lambda user: user['gender'] == 'male' and user['age'] > 18, users))

print(filtered_users)
